<?php
$a = explode("/",$_GET['s-url']);
include_once('simple_html_dom.php');
$html = file_get_html($_GET['s-url']);

if($_GET['s-target']!=null){
	
	
	
	
	
echo '<div class="container form-group">
    <label for="exampleFormControlSelect2">Example multiple select</label>
    <select multiple class="form-control" id="exampleFormControlSelect2">
';



foreach($html->find($_GET['s-target']) as $element){
		
	
	if($_GET['s-val']==null){
       echo '<option>'.$element.'</option>'."<br/>\n";
	}else{
       echo 
	   '<option value="'. $element->{$_GET['s-val']} . '">' . 
	   $element . '</option>'.
	   "<br/>\n";
	}
}



echo '    </select>
<hr/><center>
';	

   
}
else
{
foreach($html->find('a') as $element)
       $element->href = "http://sheva.my.id/go.php?s-url=".$element->href;
echo $html;
}
?>

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

<style type="text/css">
    .form-control {
        height: 50% !important;
    }
</style>


<button class="btn btn-primary" onclick="sortList()">Sort</button>	
<button class="btn btn-secondary" id="getAll">Get</button><hr/>	

	<div class="form-group">
		<textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
	</div>
</div>

<script>
    $(document).ready(function() {
        $("#getAll").click(function(){
            var favorite = [];
            $.each($("option:selected"), function(){            
                favorite.push($(this).val());
            });
            // alert("My favourite are: \n" + favorite.join("\n"));
            document.getElementById("exampleFormControlTextarea1").value = favorite.join("\n");
        });
    });
</script>



<script>
function sortList() {
  var list, i, switching, b, shouldSwitch;
  list = document.getElementById("exampleFormControlSelect2");
  switching = true;
  /* Make a loop that will continue until
  no switching has been done: */
  while (switching) {
    // start by saying: no switching is done:
    switching = false;
    b = list.getElementsByTagName("option");
    // Loop through all list-items:
    for (i = 0; i < (b.length - 1); i++) {
      // start by saying there should be no switching:
      shouldSwitch = false;
      /* check if the next item should
      switch place with the current item: */
      if (b[i].innerHTML.toLowerCase() > b[i + 1].innerHTML.toLowerCase()) {
        /* if next item is alphabetically
        lower than current item, mark as a switch
        and break the loop: */
        shouldSwitch = true;
        break;
      }
    }
    if (shouldSwitch) {
      /* If a switch has been marked, make the switch
      and mark the switch as done: */
      b[i].parentNode.insertBefore(b[i + 1], b[i]);
      switching = true;
    }
  }
}
</script>



<!-- https://www.tutorialrepublic.com/codelab.php?topic=faq&file=jquery-get-values-of-selected-checboxes -->