<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Tools Proxy Skip Sheva">
    <meta name="author" content="Joe Bhakti Rendeun">
    <link rel="icon" href="https://getbootstrap.com/docs/4.0/assets/img/favicons/favicon.ico">

    <title>Sheva Tools</title>


    <!-- Bootstrap core CSS -->
    <link href="https://getbootstrap.com/docs/4.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="https://getbootstrap.com/docs/4.0/examples/sign-in/signin.css" rel="stylesheet">
  </head>

  <body class="text-center">
    <form class="form-signin" method="get" action="go.php">
      <img class="mb-4" src="https://dummyimage.com/400x400/000/fff&text=S" alt="" width="72" height="72">
      <h1 class="h3 mb-3 font-weight-normal">Masukan URL</h1>
      <input name="s-url" class="form-control" placeholder="http://google.com" required autofocus><br/>
      <input name="s-target" class="form-control" placeholder="a[rel=noreferer]*" autofocus>
      <input name="s-val" class="form-control" placeholder="href, src, plaintext*" autofocus>
	  <hr/>
      <button class="btn btn-lg btn-primary btn-block" type="submit">GO</button>
      <p class="mt-5 mb-3 text-muted">&copy; 2020</p>
    </form>
  </body>
</html>